﻿using HarmonyLib;
using Unity.Collections;
using Unity.Entities;

/// <summary>
/// Disables spawning of a bunch of environment objects, like grass and plants (outside scenes, dungeons, and sub-biomes).
/// </summary>
[HarmonyPatch(typeof(SpawnEnvironmentObjectsInNewAreaSystem), "OnUpdate")]
public static class DisableEnvironmentSpawnPatch
{
	// The Prefix runs right before the original function (return controls whether to continue with original function)
	[HarmonyPrefix]
	public static bool Prefix(ref SystemState state)
	{
		var ecb = new EntityCommandBuffer(Allocator.Temp);
		state.Dependency = default;
		
		using var environmentSpawnQuery = state.EntityManager.CreateEntityQuery(ComponentType.ReadOnly<SpawnEnvironmentObjectsInAreaCD>());

		// This is the minimal setup required to pass on the new area to the next step in the world gen pipeline
		ecb.RemoveComponent<SpawnEnvironmentObjectsInAreaCD>(environmentSpawnQuery, EntityQueryCaptureMode.AtRecord);
		ecb.AddComponent<SpawnTerritoriesInAreaCD>(environmentSpawnQuery, EntityQueryCaptureMode.AtRecord);
		
		ecb.Playback(state.EntityManager);
		ecb.Dispose();
		
		// Return false to not call the original method
		return false; 
	}
}